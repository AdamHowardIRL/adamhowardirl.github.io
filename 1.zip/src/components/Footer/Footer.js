import React, {Component} from 'react';

class Footer extends Component {
  render() {
    return (
      <footer className="app-footer">
        <a href="http://www.adamhoward.io">Adam Howard</a> &copy; 2017.
      </footer>
    )
  }
}

export default Footer;
