# Deprecated! All files will be moved to new repository.

We decided to move React Version to separate repository. You can find all files here: [CoreUI React Version](https://github.com/mrholek/CoreUI-React)
